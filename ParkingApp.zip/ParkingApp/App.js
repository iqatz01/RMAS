import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import React from 'react';
import { StatusBar } from 'expo-status-bar';

import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

import LoginScreen from './LoginScreen';
import RegisterScreen from './RegisterScreen';
import MainScreen from './MainScreen';
import UserScreen from './UserScreen';
import ParkingListScreen from './ParkingListScreen';

const Stack = createStackNavigator();

const firebaseConfig = {
  apiKey: 'AIzaSyAixn-5yq4ZE7sPOgus28QlStBUJjXI41M',
  authDomain: 'parkingapp-4bc22.firebaseapp.com',
  projectId: 'parkingapp-4bc22',
  storageBucket: 'parkingapp-4bc22.appspot.com',
  messagingSenderId: '248927689900',
  appId: '1:248927689900:web:4775f147f7026fe6cf9309',
  databaseURL: 'https://parkingapp-4bc22-default-rtdb.europe-west1.firebasedatabase.app/',
};

const app = initializeApp(firebaseConfig);

const auth = getAuth(app);
const db = getFirestore(app);


export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Prijava" component={LoginScreen} />
        <Stack.Screen name="Registracija" component={RegisterScreen} />
        <Stack.Screen name="ParkiraNI" component={MainScreen} />
        <Stack.Screen name="Nalog" component={UserScreen} />
        <Stack.Screen name="Lista parkinga" component={ParkingListScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

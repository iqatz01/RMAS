import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ImageBackground } from 'react-native';
import { getAuth, signInWithEmailAndPassword } from 'firebase/auth';

const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');

  const handleLogin = async () => {
    setEmailError('');
    setPasswordError('');
  
    const auth = getAuth();
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      const userId = user.uid;
  
      // Ako je prijava uspešna, navigiraj na ekran za uspešnu prijavu
      if (userId) {
        navigation.navigate('ParkiraNI', { userId,  navigation  }  ); // Prosleđivanje userId
      }
    } catch (error) {
      console.error('Error logging in:', error);
  
      if (error.code === 'auth/user-not-found' || error.code === 'auth/invalid-email') {
        setEmailError('Korisnik sa ovom email adresom ne postoji.');
      } else if (error.code === 'auth/wrong-password') {
        setPasswordError('Pogrešna lozinka.');
      } // Dodajte više uslova za ostale moguće greške
    }
  };

  const navigateToRegister = () => {
    navigation.navigate('Registracija');
  };

  return (
    <ImageBackground source={require('./assets/cars-bg-mbgb.png')} style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.title}>ParkiraNI</Text>
        <TextInput
          style={[styles.input, emailError && styles.errorInput]}
          placeholder="Email adresa"
          value={email}
          onChangeText={(text) => {
            setEmail(text);
            setEmailError('');
          }}
        />
        {emailError ? <Text style={styles.errorMessage}>{emailError}</Text> : null}
        <TextInput
          style={[styles.input, passwordError && styles.errorInput]}
          placeholder="Lozinka"
          secureTextEntry
          value={password}
          onChangeText={(text) => {
            setPassword(text);
            setPasswordError('');
          }}
        />
        {passwordError ? <Text style={styles.errorMessage}>{passwordError}</Text> : null}
        <TouchableOpacity style={styles.button} onPress={handleLogin}>
          <Text style={styles.buttonText}>Prijavi se</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={navigateToRegister}>
          <Text style={styles.registerLink}>Nemate nalog? Registrujte se!</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0)',
  },
  title: {
    fontSize: 34,
    marginBottom: 128,
    color: 'rgba(0, 0, 0, 100)',
  },
  input: {
    width: '80%',
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 7,
    marginBottom: 10,
    padding: 10,
    backgroundColor: 'rgba(255, 255, 255, 0.85)',
  },
  errorInput: {
    borderColor: 'red',
  },
  errorMessage: {
    color: 'red',
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#007bff',
    padding: 10,
    borderRadius: 7,
  },
  buttonText: {
    color: 'white',
    textAlign: 'center',
  },
  registerLink: {
    marginTop: 10,
    color: '#007bff',
  },
});

export default LoginScreen;

import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, TextInput, Image, ActivityIndicator, TouchableOpacity, BackHandler, Switch } from 'react-native';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import { getDatabase, ref, push, onValue, get, set } from 'firebase/database';
import * as Location from 'expo-location';
import Slider from '@react-native-community/slider';
import DropDownPicker from 'react-native-dropdown-picker';


const MainScreen = (route) => {

  const { userId } = route.route.params;
  const navigation = route.navigation;

  const [loading, setLoading] = useState(true);
  const [location, setLocation] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);
  const [clickedCoordinate, setClickedCoordinate] = useState(null);
  const [parkingData, setParkingData] = useState({ name: '', numberOfSpaces: '', hourlyRate: '' });
  const [showForm, setShowForm] = useState(false);
  const [parkingSpots, setParkingSpots] = useState([]);
  const [occupiedSpaces, setOccupiedSpaces] = useState('');
  const [showRanking, setShowRanking] = useState(false);
  const [usersData, setUsersData] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [showUserAlert, setShowUserAlert] = useState(false);
  const [searchRadius, setSearchRadius] = useState(100);
  const [maxHourlyRate, setMaxHourlyRate] = useState(1000);
  const [showSearchForm, setShowSearchForm] = useState(false);
  const [applyFilter, setApplyFilter] = useState(false);
  const [filteredParkingSpots, setFilteredParkingSpots] = useState([]);
  const [selectedParking, setSelectedParking] = useState(null);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewComment, setReviewComment] = useState('');
  const [selectedParkingComments, setSelectedParkingComments] = useState([]);
  const [openSelectType, setOpenSelectType] = useState(false);
  const [valueSelectType, setValueSelectType] = useState(null);
  const [openSelectSize, setOpenSelectSize] = useState(false);
  const [valueSelectSize, setValueSelectSize] = useState(null);
  const [isEnabled, setIsEnabled] = useState(false);
  const mapRef = useRef(null);

  /*
  useEffect(() => {
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }, []);  */

  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setErrorMsg('Permission to access location was denied');
        return;
      }
      let currentLocation = await Location.getCurrentPositionAsync({});
      if (currentLocation) {
        setLocation(currentLocation.coords);
      } else {
        console.log('Current Location is null or undefined.');
      }
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    })();
  }, []);  // Make sure this dependency array is correct.

  useEffect(() => {
    const backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      setShowForm(false);
      setApplyFilter(false);
      setShowReviewForm(false);
      setShowSearchForm(false);
      setShowRanking(false);
      return true;
    });

    return () => {
      backHandler.remove();
    };
  }, []);



  useEffect(() => {
    const database = getDatabase();
    const parkingRef = ref(database, 'parkings');
    onValue(parkingRef, (snapshot) => {
      const parkingData = snapshot.val();
      if (parkingData) {
        const parkingList = Object.keys(parkingData).map((id) => ({
          parkingId: id,
          ...parkingData[id],
        }));
        setParkingSpots(parkingList);
      }
    });

    const usersRef = ref(database, 'users'); //izdvojiti u posebnu fju i showRanking
    onValue(usersRef, (snapshot) => {
      const usersData = snapshot.val();
      if (usersData) {
        const usersList = Object.values(usersData);
        const sortedUsers = usersList.sort((a, b) => b.score - a.score).slice(0, 10);
        setUsersData(sortedUsers);
      }
    });
  }, []);

  const getSortedUsersData = () => {
    const database = getDatabase();
    const usersRef = ref(database, 'users'); //izdvojiti u posebnu fju i showRanking
    onValue(usersRef, (snapshot) => {
      const usersData = snapshot.val();
      if (usersData) {
        const usersList = Object.values(usersData);
        const sortedUsers = usersList.sort((a, b) => b.score - a.score).slice(0, 10);
        setUsersData(sortedUsers);
      }
    });
  }

  const handleMapPress = (event) => {
    const { latitude, longitude } = event.nativeEvent.coordinate;
    setClickedCoordinate({ latitude, longitude });
    setShowForm(true);
  };

  const handleAddParking = () => {
    setShowForm(false);
    const updatedParkingSpots = [
      ...parkingSpots,
      { 
        ...clickedCoordinate, 
        ...parkingData, 
        occupiedSpaces: occupiedSpaces,
        size: valueSelectSize,
        type: valueSelectType, 
      },
    ];

    setParkingSpots(updatedParkingSpots);
    setParkingData({ numberOfSpaces: '', hourlyRate: '' });
    setOccupiedSpaces('');

    const database = getDatabase();
    const parkingRef = ref(database, 'parkings');

    const newParking = {
      latitude: clickedCoordinate.latitude,
      longitude: clickedCoordinate.longitude,
      name: parkingData.name,
      numberOfSpaces: parkingData.numberOfSpaces,
      hourlyRate: parkingData.hourlyRate,
      occupiedSpaces: occupiedSpaces,
      size: valueSelectSize,
      type: valueSelectType, 
    };

    push(parkingRef, newParking)
      .then(() => {
        console.log('Novi parking dodat u bazu.');
      })
      .catch((error) => {
        console.error('Greška prilikom dodavanja parkinga u bazu:', error);
      });
  };

  const handleParkingMarkerPress = (spot) => {
    if (location && spot) {
      const distance = calculateDistance(
        location.latitude,
        location.longitude,
        spot.latitude,
        spot.longitude
      );

      if (distance <= 100) {
        setSelectedParking(spot);
        setSelectedParkingComments([]);

        const database = getDatabase();
        const commentsRef = ref(database, `parkings/${spot.parkingId}/comments`);
  
        try {
          get(commentsRef)
            .then((commentsSnapshot) => {
              const commentsData = commentsSnapshot.val();
              if (commentsData) {
                const commentsArray = Object.values(commentsData);
                setSelectedParkingComments(commentsArray);
              }
              setShowReviewForm(true);
            })
            .catch((error) => {
              console.error('Error fetching comments:', error);
            });
        } catch (error) {
          console.error('Error fetching comments:', error);
        }
      } else {
        alert(
          'Ovaj parking nije u radijusu od 100 metara. Približi mu se da bi dodao komentar.'
        );
      }
    }
  };
 
  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371; // Radius of the Earth in kilometers
    const dLat = degToRad(lat2 - lat1);
    const dLon = degToRad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(degToRad(lat1)) * Math.cos(degToRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c * 1000; // Distance in meters
    return distance;
  };

  const degToRad = (deg) => {
    return deg * (Math.PI / 180);
  };

  const handleUserAlertClose = () => {
    setShowUserAlert(false);
    if (currentUser) {
      const alertMessage = `Username: ${currentUser.username}\nScore: ${currentUser.score}\nRank: ${rank}`;
      alert(alertMessage);
    }
  };

  const fetchCurrentUser = async () => {
    const database = getDatabase();
    const userRef = ref(database, `users/${userId}`);
  
    onValue(userRef, (snapshot) => {
      const userData = snapshot.val();
      setCurrentUser(userData);
  
      let rank = '';
      if (userData.score < 3) {
        rank = 'Pocetnik';
      } else if (userData.score < 10) {
        rank = 'Iskusan';
      } else if (userData.score >= 10) {
        rank = 'Profesionalac';
      }
  
      const alertMessage = `Username: ${userData.username}\nScore: ${userData.score}\nRank: ${rank}`;
      alert(alertMessage);
    });
  };

  const handleSearchRadiusChange = (value) => {
    setSearchRadius(value);
  };
  
  const handleMaxHourlyRateChange = (value) => {
    setMaxHourlyRate(value);
  };

  const handleSearch = () => {
    if (isEnabled) {
      // Pretraga sa svim filterima
      const newFilteredParkingSpots = parkingSpots.filter((spot) => {
        const distance = calculateDistance(
          location.latitude,
          location.longitude,
          spot.latitude,
          spot.longitude
        );
        return (
          distance <= searchRadius &&
          spot.hourlyRate <= maxHourlyRate &&
          (!valueSelectType || spot.type === valueSelectType) &&
          (!valueSelectSize || spot.size === valueSelectSize)
        );
      });
      setFilteredParkingSpots(newFilteredParkingSpots);
    } else {
      // Pretraga samo po Radijusu
      const newFilteredParkingSpots = parkingSpots.filter((spot) => {
        const distance = calculateDistance(
          location.latitude,
          location.longitude,
          spot.latitude,
          spot.longitude
        );
        return distance <= searchRadius;
      });
      setFilteredParkingSpots(newFilteredParkingSpots);
    }
  
    setApplyFilter(true);
    setShowSearchForm(false);
  };
  
  const handleReviewSubmit = () => {
    if (reviewComment && selectedParking?.parkingId) {
      const database = getDatabase();
      const parkingPath = `parkings/${selectedParking.parkingId}`;
      const spotRef = ref(database, parkingPath);
  
      get(spotRef)
        .then((snapshot) => {
          const spotData = snapshot.val();
          if (spotData) {
            if (!spotData.comments) {
              spotData.comments = []; 
            }

            spotData.comments.push({ userId, comment: reviewComment });
  
            const userRef = ref(database, `users/${userId}`);
            return get(userRef).then((userSnapshot) => {
              const userData = userSnapshot.val();
              if (userData) {
                userData.score = userData.score + 1;
                return set(userRef, userData).then(() => {
                  return set(spotRef, spotData);
                });
              }
            });
          }
        })
        .then(() => {
          console.log('Komentar je dodat na parking.');
          setReviewComment('');
          setSelectedParkingComments((prevComments) => [
            ...prevComments,
            { userId, comment: reviewComment },
          ]);
        })
        .catch((error) => {
          console.error('Greška prilikom dodavanja komentara:', error);
        });
    }
  };
  
  const initialRegion = {
    latitude: location ? location.latitude : 43.3150,
    longitude: location ? location.longitude : 21.8767,
    latitudeDelta: 0.0040,
    longitudeDelta: 0.0040,
  }
  
  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#007bff" />
      </View>
    );
  }

  // Dodajte ovu funkciju za promenu stanja detaljne pretrage
  const toggleSwitch = () => {
    setIsEnabled((previousState) => !previousState);
  };

  const searchButtonPress = () => {
    setShowRanking(false);
    setShowReviewForm(false);
    setShowForm(false);
    setShowSearchForm(!showSearchForm);
  };

  const parkingListButtonPress = () => {
    navigation.navigate('Lista parkinga', { userId, navigation })
    setShowRanking(false);
    setShowForm(false);
    setShowSearchForm(false);
    setShowReviewForm(false);
  };

  const userInfoButtonPress = () => {
    navigation.navigate('Nalog', { userId, navigation })
    setShowSearchForm(false);
    setShowRanking(false);
    setShowForm(false);
    setShowReviewForm(false);
  };

  const rankingButtonPress = () => {
    setShowSearchForm(false);
    setShowReviewForm(false);
    setShowForm(false);
    setShowRanking(!showRanking)
  };

  return (
    <View style={styles.container}>
      <MapView
        style={styles.map}
        provider={PROVIDER_GOOGLE}
        initialRegion={initialRegion}
        ref={mapRef}
        onPress={handleMapPress}
      >
        {location && (
          <Marker
            coordinate={{ latitude: location.latitude ?? 43.3150, longitude: location.longitude ?? 21.8767 }}
            title="Trenutna lokacija"
          />
        )}
        {(applyFilter ? filteredParkingSpots : parkingSpots).map((spot, index) => {
          const distance = calculateDistance(
            location.latitude,
            location.longitude,
            spot.latitude,
            spot.longitude
          );
  
          const isWithinRadius = distance <= 100;
  
          return (
            <Marker
              key={index}
              coordinate={{ latitude: spot.latitude, longitude: spot.longitude }}
              onPress={() => handleParkingMarkerPress(spot)}
            >
              <View style={styles.markerContainer}>
                <Image
                  source={
                    isWithinRadius
                      ? require('./assets/parking.png')
                      : require('./assets/parking-gray.png')
                  }
                  style={styles.image}
                />
                <Text style={styles.spacesText}>
                  {spot.occupiedSpaces}/{spot.numberOfSpaces}
                </Text>
                <Text style={styles.rateText}>{spot.hourlyRate} rsd/h</Text>
              </View>
            </Marker>
          );
        })}
      </MapView>
  
      <TouchableOpacity style={styles.floatingButton} onPress={() => rankingButtonPress()}>
        <Image source={require('./assets/podium128.png')} style={styles.floatingButtonImage} />
      </TouchableOpacity>
   
      <View style={styles.floatingButtonsContainer}>
      <TouchableOpacity style={styles.userFloatingButton} onPress={() => userInfoButtonPress()}>
        <Image source={require('./assets/user64.png')} style={styles.smallFloatingButtonImage} />
      </TouchableOpacity>

      <TouchableOpacity style={styles.parkingListFloatingButton} onPress={() => parkingListButtonPress()}>
        <Image source={require('./assets/parking-list64.png')} style={styles.smallFloatingButtonImage} />
      </TouchableOpacity>
  
      <TouchableOpacity style={styles.searchFloatingButton} onPress={() => searchButtonPress()}>
        <Image source={require('./assets/search64.png')} style={styles.smallFloatingButtonImage} />
      </TouchableOpacity>
      </View>

      {showRanking && (
        <View style={styles.formContainer}>
          <Text style={styles.rankListTitle}>Rang lista</Text>
          <View style={styles.rankTable}>
            <View style={styles.tableHeader}>
              <Text style={styles.tableHeaderCell}>Pozicija</Text>
              <Text style={styles.tableHeaderCell}>Korisnik</Text>
              <Text style={styles.tableHeaderCell}>Poeni</Text>
            </View>
            {usersData.map((user, index) => (
              <View style={styles.tableRow} key={index}>
                <Text style={styles.tableCell}>{index + 1}</Text>
                <Text style={styles.tableCell}>{user.username}</Text>
                <Text style={styles.tableCell}>{user.score}</Text>
              </View>
            ))}
          </View>
    
          <TouchableOpacity style={styles.searchButton} onPress={() => setShowRanking(false)}>
            <Text style={styles.searchButtonText}>Zatvori</Text>
          </TouchableOpacity>
        </View>
      )}

      {showForm && (
        <View style={styles.formContainer}>
          <TextInput
           style={styles.input}
           placeholder="Naziv parkinga" // Dodajte labelu za ime parkinga
           value={parkingData.name}
           onChangeText={(text) => setParkingData({ ...parkingData, name: text })}
          />
          <TextInput
            style={styles.input}
            placeholder="Broj parking mesta"
            value={parkingData.numberOfSpaces}
            onChangeText={(text) => setParkingData({ ...parkingData, numberOfSpaces: text })}
          />
          <TextInput
            style={styles.input}
            placeholder="Zauzeta mesta"
            value={occupiedSpaces}
            onChangeText={(text) => setOccupiedSpaces(text)}
          />
          <TextInput
            style={styles.input}
            placeholder="Cena po satu"
            value={parkingData.hourlyRate}
            onChangeText={(text) => setParkingData({ ...parkingData, hourlyRate: text })}
          />
         
    <DropDownPicker
      open={openSelectType}
      value={valueSelectType}
      placeholder="Izaberi tip parkinga"
      items={[
              {label: 'Površinski', value: '1'}, 
              {label: 'Podzemna garaža', value: '2'},
              {label: 'Nadzemna garaža', value: '3'},
              {label: 'Parking sa punjačem za EV', value: '4'}
      ]}
      defaultValue={1}
      setOpen={(status) => {
        setOpenSelectType(status);
        setOpenSelectSize(false);
      }}
      setValue={setValueSelectType}
      dropDownStyle={{ backgroundColor: '#fafafa' }}
      containerStyle={{ height: 40, marginBottom: 20 }}
      style={{ backgroundColor: '#fafafa' }}
      itemStyle={{
          justifyContent: 'flex-start',
      }}
  />

    <DropDownPicker
      open={openSelectSize}
      value={valueSelectSize}
      placeholder="Izaberi veličinu parkinga"
      items={[
              {label: 'Mala', value: '1'}, 
              {label: 'Srednja', value: '2'},
              {label: 'Velika', value: '3'},
      ]}
      defaultValue={1}
      setOpen={(status) => {
        setOpenSelectSize(status);
        setOpenSelectType(false);
      }}
      setValue={setValueSelectSize}
      dropDownStyle={{ backgroundColor: '#fafafa' }}
      containerStyle={{ height: 40, marginBottom: 20  }}
      style={{ backgroundColor: '#fafafa' }}
      itemStyle={{
          justifyContent: 'flex-start',
      }}
  />
          <TouchableOpacity style={styles.searchButton} onPress={handleAddParking}>
            <Text style={styles.searchButtonText}>Dodaj</Text>
          </TouchableOpacity>
        </View>
      )}

      {showUserAlert && (
        <View style={styles.userAlert}>
          <Text style={styles.userAlertText}>Kliknuto!</Text>
          <TouchableOpacity style={styles.searchButton} onPress={handleUserAlertClose}>
            <Text style={styles.searchButtonText}>Zatvori</Text>
          </TouchableOpacity>
        </View>
      )}

{showReviewForm && selectedParking && (
  <View style={styles.formContainer}>

    <View style={styles.commentContainer}>
     <Text style={styles.rankListTitle}>Komentari</Text>
    {selectedParkingComments.map((comment, index) => (
      <View key={index} style={styles.commentText}>
        <Text style={styles.commentText}>{comment.comment}</Text>
      </View>
    ))}
    </View>

    <TextInput
      style={styles.input}
      placeholder="Unesite komentar..."
      value={reviewComment}
      onChangeText={setReviewComment}
      multiline
    />

    <TouchableOpacity style={styles.searchButton} onPress={handleReviewSubmit}>
      <Text style={styles.searchButtonText}>Dodaj komentar</Text>
    </TouchableOpacity>
    
  </View>
)}

{showSearchForm && (
  <View style={styles.searchFormContainer}>
    <Text style={styles.formTitle}>Pretraga</Text>
    <Text style={styles.formSubtitle}>Filteri</Text>
    <Text style={styles.label}>Radijus</Text>
    <Slider
      style={styles.slider}
      minimumValue={10}
      maximumValue={1000}
      step={10}
      value={searchRadius}
      onValueChange={handleSearchRadiusChange}
    />
    <Text style={styles.sliderValue}>{searchRadius}m</Text>

  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
    <Switch onValueChange={toggleSwitch}
            value={isEnabled}
            />
             <Text>
    Detaljna pretraga <Text style={{ color: isEnabled ? 'green' : 'red' }}>{isEnabled ? 'uključena' : 'isključena'}</Text>
  </Text>
  </View>
    <Text style={styles.label}>Maksimalna cena</Text>
    <Slider
      style={styles.slider}
      minimumValue={0}  
      maximumValue={2000}
      step={10}
      value={maxHourlyRate}
      onValueChange={handleMaxHourlyRateChange}
      tintColor='red'
    />
    <Text style={styles.sliderValue}>{maxHourlyRate} rsd/h</Text>

    <Text style={styles.label}>Tip garaže</Text>
<DropDownPicker
      open={openSelectType}
      value={valueSelectType}
      placeholder="Izaberi tip garaže"
      items={[
              {label: 'Površinski', value: '1'}, 
              {label: 'Podzemna garaža', value: '2'},
              {label: 'Nadzemna garaža', value: '3'},
              {label: 'Parking sa punjačem za EV', value: '4'}
      ]}
      defaultValue={1}
      setOpen={(status) => {
        setOpenSelectType(status);
        setOpenSelectSize(false);
      }}
      setValue={setValueSelectType}
      dropDownStyle={{ backgroundColor: '#fafafa', marginBottom: 20 }}
      containerStyle={{ height: 40, marginBottom: openSelectType ? 180 : 20 }}
      style={{ backgroundColor: '#fafafa' }}
      itemStyle={{
          justifyContent: 'flex-start',
      }}
  />

<Text style={styles.label}>Veličina garaže</Text>
<DropDownPicker
      open={openSelectSize}
      value={valueSelectSize}
      placeholder="Izaberi veličinu garaže"
      items={[
              {label: 'Mala', value: '1'}, 
              {label: 'Srednja', value: '2'},
              {label: 'Velika', value: '3'},
      ]}
      defaultValue={1}
      setOpen={(status) => {
        setOpenSelectSize(status);
        setOpenSelectType(false);
      }}
      setValue={setValueSelectSize}
      dropDownStyle={{ backgroundColor: '#fafafa', marginBottom: 20 }}
      containerStyle={{ height: 40, marginTop: openSelectSize ? 120 : 0, marginBottom: 20}}
      dropDownContainerStyle={{ marginBottom: -10}}
      style={{ backgroundColor: '#fafafa' }}
      itemStyle={{
          justifyContent: 'flex-start',
      }}
  />
    <TouchableOpacity style={styles.searchButton} onPress={handleSearch}>
      <Text style={styles.searchButtonText}>Pretraži</Text>
    </TouchableOpacity>
    <TouchableOpacity style={[styles.searchButton, { marginTop: 8}]} onPress={() => setShowSearchForm(false)}>
      <Text style={styles.searchButtonText}>Otkaži</Text>
    </TouchableOpacity>
  </View>
)}
</View>  
  );
};

const styles = StyleSheet.create({
  searchFormContainer: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    right: 20,
    backgroundColor: 'white',
    padding: 10,
    borderRadius: 7,
    elevation: 5,
  },
  formTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
  },
  formSubtitle: {
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 10,
  },
  label: {
    fontSize: 12,
    marginBottom: 5,
  },
  slider: {
    marginBottom: 10,
  },
  sliderValue: {
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 10,
  },
  searchButton: {
    backgroundColor: '#007bff',
    borderRadius: 7,
    padding: 10,
    elevation: 5,
  },
  searchButtonText: {
    fontSize: 14,
    color: 'white',
    textAlign: 'center',
  },
  rankListTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center'
  },
  rankTable: {
    backgroundColor: 'white',
    borderRadius: 7,
    padding: 10,
    elevation: 5,
    marginBottom: 10

  },
  tableHeader: {
    display: 'flex',
    flexDirection: 'row',
  },
  tableRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 5,
  },
  tableCell: {
    flex: 1,
    fontSize: 12,
  },
  tableHeaderCell: {
    flex: 1,
    fontSize: 14,
    fontWeight: 'bold',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
  },
  map: {
    width: '100%',
    height: '100%',
  },
  formContainer: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    right: 20,
    backgroundColor: 'white',
    padding: 10,
    borderRadius: 7,
    elevation: 5,
  },
  input: {
    marginBottom: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: 'gray',
    borderRadius: 7,
  },
  rateText: {
    fontSize: 8,
  },
  spacesText: {
    fontSize: 10,
  },
  markerContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  image: {
    width: 32,
    height: 32,
  },
  floatingButton: {
    position: 'absolute',
    bottom: 20,
    right: 20,
    backgroundColor: '#007bff',
    borderRadius: 30,
    padding: 10,
    elevation: 5,
  },
  floatingButtonImage: {
    width: 32,
    height: 32,
    tintColor: 'white',
  },
  smallFloatingButtonImage: {
    width: 22,
    height: 22,
    tintColor: 'white',
  },
  userFloatingButton: {
    position: 'absolute',
    top: 10,
    right: 20,
    backgroundColor: '#007bff',
    borderRadius: 30,
    padding: 7,
    elevation: 5,
  },
  userAlert: {
    position: 'absolute',
    top: '40%',
    left: '25%',
    width: '50%',
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 7,
    elevation: 5,
  },
  userAlertText: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 10,
  },
  searchFloatingButton: {
    position: 'absolute',
    top: 10,
    right: 108,
    backgroundColor: '#007bff',
    borderRadius: 30,
    padding: 7,
    elevation: 5,
  },
  parkingListFloatingButton: {
    position: 'absolute',
    top: 10,
    right: 64,
    backgroundColor: '#007bff',
    borderRadius: 30,
    padding: 7,
    elevation: 5,
  },
  floatingButtonsContainer: {
    position: 'absolute',
    top: 0,
    right: 0,
    flexDirection: 'row',
  },
  dropdown: {
    borderWidth: 1,
    borderColor: 'gray',
    borderRadius: 7,
    padding: 10,
    marginBottom: 10,
  },
  dropdownText: {
    fontSize: 16,
  },
  dropdownContainer: {
    width: 'auto', 
    maxHeight: 150, 
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 7,
  },
  button: {
    borderRadius: 7
  },
  commentContainer: {
    paddingLeft: 10,
    paddingBottom: 10
  }, 
  switchText: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  enabledText: {
    color: 'green',
  },
  disabledText: {
    color: 'red',
  },
});

export default MainScreen;

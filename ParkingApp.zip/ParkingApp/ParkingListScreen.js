import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, BackHandler } from 'react-native';
import { getDatabase, ref, onValue } from 'firebase/database';

const ParkingListScreen = ({ route }) => {

  //const { userId } = route.params; 
  const navigation = route.params.navigation;  
  const [parkings, setParkings] = useState([]);

  //console.log(route.params.navigation);

  useEffect(() => {
    const backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      // Ovde možete dodati dodatnu logiku pre povratka, ako je potrebno.
      // Na primer, možete prikazati dijalog za potvrdu povratka.

      // Ako želite da se vratiš na prethodni ekran, koristi navigation.goBack()
      navigation.goBack();

      // Vraćamo true da označimo da smo se uspešno nosili sa Back dugmetom.
      return true;
    });

    // Vraćamo funkciju za čišćenje prilikom unmount-a komponente
    return () => {
      backHandler.remove();
    };
  }, [navigation]);

  useEffect(() => {
    const fetchParkings = async () => {
      const database = getDatabase();
      const parkingRef = ref(database, 'parkings');

      onValue(parkingRef, (snapshot) => {
        const parkingData = snapshot.val();
        if (parkingData) {
          const parkingList = Object.keys(parkingData).map((id) => ({
            parkingId: id,
            ...parkingData[id],
          }));
          setParkings(parkingList);
        }
      });
    };

    fetchParkings();
  }, []);

  const renderParkingItem = ({ item }) => (
    <TouchableOpacity
      style={styles.itemContainer}
    >
    <View style={styles.textContainer}>
      <Text style={styles.parkingName}>{item.name}</Text>
      <Text style={styles.parkingId}>({item.parkingId})</Text>
    </View>
    <View style={styles.textContainer}>
      <Text style={styles.spaces}>{item.occupiedSpaces} / {item.numberOfSpaces}</Text>
      <Text style={styles.price}>{item.hourlyRate} rsd/h</Text>
    </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={parkings}
        keyExtractor={(item) => item.parkingId}
        renderItem={renderParkingItem}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    padding: 16,
  },
  textContainer: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'baseline'
  },
  itemContainer: {
    backgroundColor: '#f0f0f0',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
  },
  parkingName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  parkingId: {
    fontSize: 10,
    marginLeft: 6
  },
  price: {
    marginLeft: 20
  },
  spaces: {
    width: '25%'
  }
  
});

export default ParkingListScreen;

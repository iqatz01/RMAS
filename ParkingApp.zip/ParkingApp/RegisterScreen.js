import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ImageBackground, Image, KeyboardAvoidingView, Platform, ActivityIndicator } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { getAuth, createUserWithEmailAndPassword } from 'firebase/auth';
import { getDatabase, ref, get, set } from 'firebase/database';
import { getDownloadURL, ref as storageRef, uploadBytes, getStorage, StorageErrorCode } from 'firebase/storage'
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'

const RegisterScreen = ({ navigation }) => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [profileImage, setProfileImage] = useState(null);
  const [emailError, setEmailError] = useState('');
  const [passwordMatchError, setPasswordMatchError] = useState('');
  const [nameError, setNameError] = useState('');
  const [registrationError, setRegistrationError] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);

  useEffect(() => {
    (async () => {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        alert('Sorry, we need camera roll permissions to make this work!');
      }
    })();
  }, []);

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 1,
    });

    if (!result.canceled) {
      setProfileImage(result.assets[0].uri);
    }
  };

  const takePicture = async () => {
    let result = await ImagePicker.launchCameraAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 1,
    });

    if (!result.canceled) {
      setProfileImage(result.assets[0].uri);
    }
  };

  const handleRegister = async () => {
    setEmailError('');
    setPasswordMatchError('');
    setNameError('');
    setRegistrationError('');

    // Provera validnosti email adrese
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setEmailError('Nevalidna email adresa!');
      return;
    }

    // Provera podudaranja lozinke i potvrde lozinke
    if (password !== confirmPassword) {
      setPasswordMatchError('Lozinke se ne podudaraju!');
      return;
    }

    // Provera da ime i prezime sadrže samo slova
    const nameRegex = /^[A-Za-zčćžšđČĆŽŠĐ]+$/;
    if (!nameRegex.test(firstName) || !nameRegex.test(lastName)) {
      setNameError('Ime i prezime mogu sadržati samo slova!');
      return;
    }

    const auth = getAuth();
    try {
      // Provera da li email već postoji u bazi
      const database = getDatabase();
      const emailExists = await emailExistsInDatabase(database, email);
      if (emailExists) {
        setEmailError('Korisnik sa ovom email adresom je već registrovan!');
        return;
      }

      // Postavite isRegistering na true pre nego što počnete registraciju
      setIsRegistering(true);

      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      const userId = user.uid;

      const userRef = ref(database, `users/${userId}`);

      const userData = {
        username,
        email,
        firstName,
        lastName,
        phoneNumber,
        score: 0,
      };

      await set(userRef, userData);
      await uploadImage(userId);

      navigation.navigate('Prijava');
    } catch (error) {
      console.error('Error registering:', error);
      if (error.code === 'auth/email-already-in-use') {
        setEmailError('Korisnik sa ovom adresom je već registrovan!');
      } else if (error.code === 'auth/invalid-email') {
        setEmailError('Nevalidna email adresa');
      }
    } finally {
      // Postavite isRegistering na false kada je registracija završena (uspešno ili neuspešno)
      setIsRegistering(false);
    }
  };

  const uploadImage = async (userId) => {
    if (userId) {
      const storage = getStorage();
      try {
        const imageRef = storageRef(storage, `profile_images/${userId}.jpg`);
        const response = await fetch(profileImage);
        const blob = await response.blob();
        await uploadBytes(imageRef, blob);

        const downloadURL = await getDownloadURL(imageRef);
        console.log('Slika uspešno dodata');
      } catch (error) {
        console.error('Greška prilikom dodavanja slike', error);
      }
    }
  }

  const emailExistsInDatabase = async (database, emailToCheck) => {
    const usersRef = ref(database, 'users');
    const snapshot = await get(usersRef);
    if (snapshot.exists()) {
      const users = snapshot.val();
      const userWithEmail = Object.values(users).find(user => user.email === emailToCheck);
      return !!userWithEmail;
    }
    return false;
  };

  return (
    <ImageBackground source={require('./assets/cars-bg-mbgb.png')} style={styles.container}>
      <KeyboardAwareScrollView
  style={{ flex: 1 }}
  contentContainerStyle={{display: 'flex', justifyContent: 'center', alignItems: 'center' }}
  enableOnAndroid={true} // Omogućava scroll na Androidu
  extraScrollHeight={Platform.select({ ios: 50, android: 100 })} // Dodatna visina za skrolovanje, prilagodite po potrebi
>
     
          <Text style={styles.title}>ParkiraNI</Text>
          
          <TextInput
            style={[styles.input, emailError && styles.errorInput]}
            placeholder="Email adresa"
            value={email}
            onChangeText={text => setEmail(text)}
          />
          <Text style={[styles.errorText, emailError && styles.errorTextRed]}>{emailError}</Text>
          <TextInput
            style={styles.input}
            placeholder="Lozinka"
            secureTextEntry
            value={password}
            onChangeText={text => setPassword(text)}
          />
          <TextInput
            style={[styles.input, passwordMatchError && styles.errorInput]}
            placeholder="Potvrdi lozinku"
            secureTextEntry
            value={confirmPassword}
            onChangeText={text => setConfirmPassword(text)}
          />
          <Text style={[styles.errorText, passwordMatchError && styles.errorTextRed]}>
            {passwordMatchError}
          </Text>
          <View style={styles.rowContainer}>
          <TextInput
            style={[styles.inputRowLeft, nameError && styles.errorInput]}
            placeholder="Ime"
            value={firstName}
            onChangeText={text => setFirstName(text)}
          />
          <TextInput
            style={[styles.inputRowRight, nameError && styles.errorInput]}
            placeholder="Prezime"
            value={lastName}
            onChangeText={text => setLastName(text)}
          />
          </View>
          <Text style={[styles.errorText, nameError && styles.errorTextRed]}>{nameError}</Text>
          <TextInput
            style={[styles.input, nameError && styles.errorInput]}
            placeholder="Korisničko ime"
            value={username}
            onChangeText={text => setUsername(text)}
          />
          <TextInput
            style={styles.input}
            placeholder="Broj telefona"
            value={phoneNumber}
            onChangeText={text => setPhoneNumber(text)}
          />
          <View style={styles.buttonRow}>
  {/* Leva strana za korisničku sliku */}
  <View style={styles.userPictureContainer}>
  {profileImage ? (
    <Image source={{ uri: profileImage }} style={styles.profileImage} />
  ) : (
    <Image source={require('./assets/default-user-image.png')} style={styles.profileImage} />
  )}
</View>

  {/* Desna strana za dugmadi */}
  <View style={styles.buttonsContainer}>
    <TouchableOpacity style={styles.photoButton} onPress={pickImage}>
      <Text style={styles.buttonText}>Izaberi fotografiju</Text>
    </TouchableOpacity>
    <TouchableOpacity style={styles.photoButton} onPress={takePicture}>
      <Text style={styles.buttonText}>Napravi fotografiju</Text>
    </TouchableOpacity>
  </View>
</View>
          
          <TouchableOpacity style={styles.registerButton} onPress={handleRegister}>
            <Text style={styles.buttonText}>Registruj se</Text>
          </TouchableOpacity>

          {/* Prikazi ActivityIndicator ako je registracija u toku */}
          {isRegistering && <ActivityIndicator size="large" color="#007bff" />}

          <Text style={[styles.errorText, registrationError && styles.errorTextRed]}>
            {registrationError}
          </Text>
        
      </KeyboardAwareScrollView>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0)',
  },
  title: {
    fontSize: 32,
    marginBottom: 16,
    marginTop: 16,
    color: 'black',
  },
  input: {
    width: '80%',
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 7,
    marginBottom: 10,
    padding: 10,
    backgroundColor: 'rgba(255, 255, 255, 0.85)',
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '81%',
    marginBottom: 16,
    marginTop: 16
  },
  rowContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '80%',
  },
  photoButtonLeft: {
    backgroundColor: 'grey',
    padding: 10,
    borderRadius: 7,
    flex: 1,
    marginRight: 4,
    marginLeft: 2
  },
  photoButtonRight: {
    backgroundColor: 'grey',
    padding: 10,
    borderRadius: 7,
    flex: 1,
    marginLeft: 4,
    marginRight: 3
  },
  photoButton: {
    backgroundColor: 'grey',
    padding: 10,
    borderRadius: 7,
    flex: 1,
    marginBottom: 8,
    marginRight: 3,
  },
  buttonText: {
    color: 'white',
    textAlign: 'center',
  },
  profileImage: {
    width: 90,
    height: 90,
    //marginBottom: 10,
    borderRadius: 50,
  },
  registerButton: {
    backgroundColor: '#007bff',
    padding: 10,
    borderRadius: 7,
    width: '80%',
  },
  inputRowLeft: {
    width: '80%',
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 7,
    marginBottom: 10,
    padding: 10,
    backgroundColor: 'rgba(255, 255, 255, 0.85)',
    flex: 1,
    marginRight: 4
  },
  inputRowRight: {
    width: '80%',
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 7,
    marginBottom: 10,
    padding: 10,
    backgroundColor: 'rgba(255, 255, 255, 0.85)',
    flex: 1,
    marginLeft: 4
  },
  buttonText: {
    color: 'white',
    textAlign: 'center',
  },
  errorInput: {
    borderColor: 'red',
  },
  errorText: {
    color: 'black',
    marginBottom: 2,
    textAlign: 'center',
  },
  errorTextRed: {
    color: 'red',
  },
  userPictureContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1
  },
});

export default RegisterScreen;

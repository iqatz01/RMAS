import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image, BackHandler, TouchableOpacity } from 'react-native';
import { getDatabase, ref, onValue } from 'firebase/database';
import { getDownloadURL, ref as storageRef } from 'firebase/storage';


const UserScreen = ({ route }) => {
  const { userId } = route.params;
  const navigation = route.params.navigation;
  const [user, setUser] = useState(null);
  const [userRank, setUserRank] = useState('');
  const [userImageURL, setUserImageURL] = useState(null);



  useEffect(() => {
    const backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      // Ovde možete dodati dodatnu logiku pre povratka, ako je potrebno.
      // Na primer, možete prikazati dijalog za potvrdu povratka.

      // Ako želite da se vratiš na prethodni ekran, koristi navigation.goBack()
      navigation.goBack();

      // Vraćamo true da označimo da smo se uspešno nosili sa Back dugmetom.
      return true;
    });

    // Vraćamo funkciju za čišćenje prilikom unmount-a komponente
    return () => {
      backHandler.remove();
    };
  }, [navigation]);

  useEffect(() => {
    const fetchUserData = async () => {
      const database = getDatabase();
      const userRef = ref(database, `users/${userId}`);
  
      onValue(userRef, async (snapshot) => {
        const userData = snapshot.val();
        setUser(userData);
  
        if (userData.score < 3) {
          setUserRank('Početnik');
        } else if (userData.score < 10) {
          setUserRank('Iskusan');
        } else if (userData.score >= 10) {
          setUserRank('Profesionalac');
        }
  
        // Konstruisanje URL-a slike korisnika na osnovu userId
        const userImageURL = `https://firebasestorage.googleapis.com/v0/b/parkingapp-4bc22.appspot.com/o/profile_images%2F${userId}.jpg?alt=media`;
  
        // Postavite URL slike u stanje userImageURL
        setUserImageURL(userImageURL);
      });
    };
  
    fetchUserData();
  }, [userId]);
  
  

  return (
    <View style={styles.container}>
      <Image
  source={userImageURL ? { uri: userImageURL } : require('./assets/user-image.png')}
  style={styles.profileImage}
/>
      {user && (
        <View>
          <Text style={styles.name}>{user.firstName} {user.lastName}</Text>
          <Text style={styles.username}>(@{user.username})</Text>
          <Text style={styles.rank}>Rank: {userRank} ({user.score} poena)</Text>
          
          <Text style={styles.email}>Email: {user.email}</Text>
          <Text style={styles.phone}>Telefon: {user.phoneNumber}</Text>

          <TouchableOpacity style={styles.logoutButton} onPress={() => navigation.navigate('Prijava')}>
          <Text style={styles.buttonText}>Odjavi se</Text>
        </TouchableOpacity>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    //justifyContent: 'center',
    alignItems: 'center',
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginTop: 100,
    marginBottom: 36,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  username: {
    fontSize: 16,
    marginBottom: 10,
  },
  email: {
    fontSize: 14,
  },
  phone: {
    fontSize: 14,
  },
  rank: {
    fontSize: 18,
    marginBottom: 16,
    fontWeight: 'bold',
  },
  logoutButton: {
    color: '#ffffff',
    backgroundColor: '#007bff',
    padding: 10,
    borderRadius: 7,
    marginTop: 10,
    width: '80%',
  },
  buttonText: {
    color: 'white'
  }
});

export default UserScreen;
